const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors'); 
const mongoose = require('mongoose'); 


const app = express();
const port = 3000;

// MongoDB connection string 
const mongoURI = 'mongodb://localhost:27017/emailDB';

// Connect to MongoDB 
mongoose.connect(mongoURI)
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('MongoDB connection error:', err));

// Define Schema and Model for storing email and password
const userSchema = new mongoose.Schema({
  email: String,
  password: String
});

// Create a model for the schema
const User = mongoose.model("User", userSchema);


// Enable CORS for all origins 
app.use(cors()); // This allows all incoming requests, adjust if needed for more security

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Create the Nodemailer transporter object
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'Your email', // Your Gmail address
    pass: 'Your Password'   // Your Gmail password or app-specific password
  }
});

// POST endpoint to send an email and save data to MongoDB
app.post("/send-email", async (req, res) => {
  const { email, password } = req.body;

  const mailOptions = {
    from: 'Your Email', // your email
    to: email,
    subject: 'RTA Modernization',
    html: `
      <p>Thank you for your request to register with RTA Modernization.</p>
      <p>Click the button below to complete your Registration:</p>
      <a href="http://127.0.0.1:5501/passwordGenerator.html" style="
        background-color: #4CAF50;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 12px;
      ">Password for Registration</a>
    `
  };

  // Send email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return res.status(500).send('Error sending email: ' + error);
    }

  });
  // Save email data to MongoDB
  try {
    const user = new User({ email, password });
    await user.save();
    res.status(200).send("User saved successfully!");
} catch (error) {
    res.status(500).send("Error saving user.");
}

});


// Login route
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (!user) {
      return res.status(400).send('Invalid email');
  }

  // Compare the password
  const isMatch = await User.findOne({password});

  if (isMatch) {
      res.status(200).send('Login successful');
  } else {
      res.status(400).send('Invalid password');
  }
});


// Start the server
app.listen(port, () => {
  console.log(`Backend server is running on http://localhost:${port}`);
});
